/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SERIOUS;


class Employ{
    int empid;
    String name;
   static String company="Smart Programming";

Employ(int empid,String name)
{
 this.empid=empid;
 this.name=name;

}
    
void display()
{
  System.out.println(empid+" "+name+" "+company);
}
}
public class Staticexample {
    public static void main(String[] args) {
        
    
    Employ e1 = new Employ(101,"Bibek");
    e1.display();
    Employ e2 = new Employ(55,"Rabin");
    e2.display();
}
}
