/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SERIOUS.Inheritance;


class A{
   void  showA(){
        System.out.println("A class");
    }
}
class B extends A{
    void showB(){
        System.out.println("B class");
    }
}
public class SingleInheritencw {
    public static void main(String[] args) {
        A a = new A();
        B b = new B();
        a.showA();
        b.showA();
        b.showB();
    }
}
