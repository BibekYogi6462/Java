/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SERIOUS.Abstraction;


 abstract class Vehicle

{
    abstract void  start();
    
    
}
class Car extends Vehicle
{
    void start(){
        System.out.println("strats with key");
    }
}
class Scooter extends Vehicle
{
    void start()
    {
        System.out.println("Starts with kick");
    }
}
 public class AbstractiionOne {
     public static void main(String[] args) {
         Car c = new Car();
         c.start();
         Scooter s = new Scooter();
         s.start();
         
     }
    
}
