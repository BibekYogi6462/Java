
package SERIOUS;


class Test{
    
//    Test(){
//    
//    Automatically done by compiler
//}
    
}
public class Constructor {
    public static void main(String[] args) {
        Test t = new Test();  // Automatically builds default constructor by compiler
    }
    
}
