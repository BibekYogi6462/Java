/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SERIOUS.Interface;


interface I1
{
   void show();
}

interface I2{
    void display();
}

class Test implements I1,I2{
 @Override
 public void show()
{
 System.out.println("1");
}
 public void display()
 {
     System.out.println("Displayed");
 }
 
}

public class Interfaces {
//    All should be abstract method
    public static void main(String[] args) {
        Test t = new Test();
        t.show();
        t.display();
    }
    
}
