/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SERIOUS.Polymorphism;


// same class and same method name but different arguments
//class Test{
//    
//    void show(int a)
//    {
//        System.out.println("Hello");
//    }
//    
//    void show(String S)
//    {
//        System.out.println("Hello hahah");
//    }
//}
//
//
//
//public class Overloading1 {
//    public static void main(String[] args) {
//        
//    
//    Test t = new Test();
//    t.show("s");
//    t.show(1);
//   
//}
//}



// No of argument
class Test{
    
    void show(int a, int b)
    {
        System.out.println("Hello");
    }
    
    void show(String S)
    {
        System.out.println("Hello hahah");
    }
}



public class Overloading1 {
    public static void main(String[] args) {
        
    
    Test t = new Test();
    t.show("s");
    t.show(1,2);
   
}
}