/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SERIOUS.Polymorphism;

class test
{
     void show(int a, String b)
     {
         System.out.println("1");
     }
}
class xyz extends test
{
    @Override
    void show(int a, String b)
    {
        System.out.println("2");
    }
}
public class Overriding1 {
    public static void main(String[] args) {
        test t = new test();
        t.show(1,"Sabek");
        xyz x = new xyz();
        x.show(2,"Samar");
    }
}
