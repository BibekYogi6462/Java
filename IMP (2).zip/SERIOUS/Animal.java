
package SERIOUS;


public class Animal {
    public static void eat()
    {
        System.out.println("I am eating");   
    }
     public static void run()
    {
        System.out.println("I am running");
    }
    public static void main(String[] args) {
        Animal Lion = new Animal();
        Lion.eat();
        Lion.run();
        
        Animal tiger = new Animal();
        tiger.eat();
    }
   
    
}

