/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SERIOUS.Encapsulation;


class Person{
    private String name;
    int id;
    
    public void setName(String name)
    {
        this.name = name;
    }
    
    public String getName()
    {
        
     return name;
     
    }
    
    
    public void setid(int id)
    {
     this.id = id;   
        
    }
    public int getid()
    {
        return id;
    }
    
    
}
public class Encapsulation1
{
    public static void main(String[] args) {
        Person p1 = new Person();
        p1.setName("Bibek");
        p1.setid(2);
        System.out.println(p1.getName());
        System.out.println(p1.getid());
    }
}