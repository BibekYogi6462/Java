package SERIOUS.Inheritance;



class Human {
    public void walk() {
        System.out.println("I can walk");
    }
}

class Dog extends Human {
    public void eat() {
        System.out.println("I can eat");
    }
}

class Cat extends Human {
    public void sleep() {
        System.out.println("I can sleep");
    }
}

public class MultilevelHierarchy {
    public static void main(String[] args) {
        Cat c = new Cat();
        c.walk();
        c.sleep();
    }
}
