/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SERIOUS.Inheritance;


class Bird
{
    
   public void eat()
    {
        System.out.println("I am eating");
}
}
    
 class Parrot extends Bird{
    public void fly()
     {
         System.out.println("I am flying");
     }
 }
public class Inheritence {
    public static void main(String[] args) {
        Bird b1 =  new Bird();
        Parrot p1 =  new Parrot();
        b1.eat();
        p1.eat();
        
    }
}
