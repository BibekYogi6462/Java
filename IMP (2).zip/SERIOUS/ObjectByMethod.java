/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SERIOUS;



class Janwar{
    String name;
    int age;
    
    
    public void takeit(String name,int age){
        this.name = name;
        this.age=age;
    }
    public void display()
    {
        System.out.println(name + " "+ age);
    }
       
        }
public class ObjectByMethod {
    public static void main(String[] args) {
        Janwar kukur = new Janwar();
        kukur.takeit("Seti", 16);
        kukur.display();
    }
    
}
