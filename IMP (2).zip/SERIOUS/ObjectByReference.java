/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SERIOUS;



class Animal1{
    String color;
    int age;
     
}
public class ObjectByReference {
    
    public static void main(String[] args) {
        Animal1 buzo =  new Animal1();
        buzo.color="black";
        buzo.age=16;
        System.out.println(buzo.color + " "+ buzo.age);
        
    }

    
    
}
